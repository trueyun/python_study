# newfile2.py
f = open("C:/doit/새파일.txt", 'w')
f.close()
