# file_with.py
with open("foo.txt", "w") as f:
    f.write("Life is too short, you need python")
