# read.py
f = open("C:/doit/새파일.txt", 'r')
data = f.read()
print(data)
f.close()
