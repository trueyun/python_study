# sleep1.py
import time
for i in range(10):
    print(i)
    time.sleep(1)
