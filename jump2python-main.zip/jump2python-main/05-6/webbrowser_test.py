# webbrowser_test.py
import webbrowser

webbrowser.open_new('http://python.org')
