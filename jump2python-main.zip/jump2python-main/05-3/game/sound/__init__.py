# C:/doit/game/sound/__init__.py
__all__ = ['echo']
