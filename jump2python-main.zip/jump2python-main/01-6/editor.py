# editor.py

a = "python"
print(a)
print(1 + 1)  # print 문을 사용해야 결괏값을 출력할 수 있다.
