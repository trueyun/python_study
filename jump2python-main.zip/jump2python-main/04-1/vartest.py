# vartest.py
a = 1
def vartest(a):
    a = a +1

vartest(a)
print(a)
