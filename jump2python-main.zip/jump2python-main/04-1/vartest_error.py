# vartest_error.py
def vartest(a):
    a = a + 1

vartest(3)
print(a)
