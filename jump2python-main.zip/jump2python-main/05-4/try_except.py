# try_except.py
try:
    4 / 0
except ZeroDivisionError as e:
    print(e)
