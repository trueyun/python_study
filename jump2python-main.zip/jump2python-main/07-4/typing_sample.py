# c:/doit/typing_sample.py
def add(a: int, b: int) -> int: 
    return a+b

result = add(3, 4)
print(result)
