# indent_error2.py
money = True
if money:
    print("택시를")
    print("타고")
        print("가라")
